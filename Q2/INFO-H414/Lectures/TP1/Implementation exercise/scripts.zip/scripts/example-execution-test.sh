#!/bin/bash

#USAGE: ./test-ants.sh instance folder

#inputs
instance=$1  # eil51.tsp
folder=$2    # ACO_tests

#remove previous files
mkdir -p ${folder}
rm -rf ${folder}/data-ants-best.txt
rm -rf ${folder}/data-ants-mean-*


#####################################################
### Run 20 trials for each value of the parameter ###
#####################################################

#create new files (this line changes according to what your testing)
echo "trial:m5:m10:m20:m50:m100" >> ${folder}/data-ants-best.txt

#Set initial seed for different trials
seed=1234
#number of trial (in the first trial we test the different parameters with the same seed)
for i in {1..50}; do
  AUX="${i}"
  #number of ants
  for m in {5,10,20,50,100}; do
    #Execute the algorithm using the seed and the parameters and save the output file in a folder.
    ./aco --instance ${instance} --tours 500 --ants ${m} --seed ${seed} > ${folder}/output-m${m}-${seed}.txt

    #Read the output file and extract the best tour found
    SOL=$(cat ${folder}/output-m${m}-${seed}.txt | grep -o -E 'Best [-+0-9.e]+' | cut -d ' ' -f2)
    
    #Clean files to use other R scripts (check structure in the examples)
    more +18 ${folder}/output-m${m}-${seed}.txt | sed -e '0,/^$/{' -e 's/^$/tours:quality/' -e '}' | sed 's/* //g' | sed 's/ : /:/g' | sed '/^[A-Z]/d' | sed '/^$/d' > ${folder}/output-m${m}-${seed}.tmp
    cat ${folder}/output-m${m}-${seed}.tmp > ${folder}/output-m${m}-${seed}.txt
    rm -f ${folder}/output-m${m}-${seed}.tmp

    #Save for printing (trial:bestSolutions)
    AUX="${AUX}:${SOL}"
  done
  #Print matrix of best tour found
  echo "$AUX" >>  ${folder}/data-ants-best.txt
  #Next seed
  ((seed++))
done

##################################################################
### Compute the average of the results obtianed in the trials ####
##################################################################
numTrials=0
getTrials=true

#number of ants
for m in {5,10,20,50,100}; do

	#Put file in the right format to join
	for f in ${folder}/output-m$m-*
	do
		#Replace ":" with " "
		awk -F: '{print $1,$2}' $f > $f-temp
		header=$(head -n1 $f)
		#Remove header
		sed -i -e "1d" $f-temp
	done

	#Join all files into a single one
	iter=0
	for f in ${folder}/output-m$m-*-temp
	do
		if [ $iter -eq 0 ]; then
			#First file
			tempFile=$f
			if [ $getTrials = true ] ; then
				#This condition is part of the mechanism to get
				#the number of trial only once
				((numTrials++))
			fi
		else
			#Rest of the files to join
			join -1 1 -2 1 $tempFile $f > ${folder}/temp_data-$m.txt
			cat ${folder}/temp_data-$m.txt > ${folder}/data-$m.txt
			tempFile=${folder}/data-$m.txt
		fi

		#Get the number of trials only one time
		if [ $((numTrials - 1)) -eq $iter ] && [ $getTrials ] ; then
			((numTrials++))
		fi
		((iter++))
	done
	rm -rf ${folder}/temp_*
	rm -rf ${folder}/*-temp

	#Discount 1 and set flag to false
	if [ $getTrials ]; then
		((numTrials--))
	fi
	getTrials=false

	#Compute the average
	echo $header > ${folder}/data-ants-average-m$m.txt #Header (we will use it when plotting using R)
	awk -v n=$numTrials '{
		average=0
		for(i = 2; i <= n+1; i++) {
			average = average + $i
		}
	}
	{ printf"%d:%.4f\n", $1, (average/n); }' ${folder}/data-$m.txt >> ${folder}/data-ants-average-m$m.txt
	rm -rf ${folder}/data-$m.txt
done

#Remove any unuseful file.....
rm -rf stat* cmp* best*
